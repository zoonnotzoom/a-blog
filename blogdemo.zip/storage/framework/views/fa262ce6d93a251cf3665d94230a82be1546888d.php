

<?php $__env->startSection('content'); ?>

INI bagian user

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program\xampp\htdocs\blogdemo\resources\views/user.blade.php ENDPATH**/ ?>