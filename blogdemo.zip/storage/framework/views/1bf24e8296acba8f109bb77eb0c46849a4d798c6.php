<!DOCTYPE html>
<html>
<head>
    <title>Laravel 8 Ajax CRUD Application - laravelcode.com</title>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
  
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html><?php /**PATH D:\Program\xampp\htdocs\blogdemo\resources\views/admin/admin_layout.blade.php ENDPATH**/ ?>